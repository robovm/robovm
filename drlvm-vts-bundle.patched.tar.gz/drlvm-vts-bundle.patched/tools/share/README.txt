INTEL CONTRIBUTION TO APACHE HARMONY
======================================


This archive contains the contribution to the Apache 
Harmony project from Intel. 

ARCHIVE CONTENTS
-------------------

The directory <ROOT_DIR>/tools/share contains the Java* source files, which
are used for building such tools like HARNESS, and VTS VM tests.


BUILDING
------------------------------------------------

Since these sources are used externally, no building environment is provided. 


DISCLAIMER AND LEGAL INFORMATION
------------------------------------

*) Other brands and names are the property of their respective owners.

